public class ex1 
	{
    	public static void main(String[] args) 
    		{
        		/**
 				 * 1) Escreva um algoritmo para imprimir os 1000 primeiros números inteiros.
  				*/
                System.out.println("Impressao dos 1000 primeiros numeros inteiros");
        		int x=1;
        		for (x=1; x<=1000; x=x+1)
        			{
                        System.out.println(x);
        			} 
    		}
}